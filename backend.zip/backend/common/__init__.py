# Common utilities module

