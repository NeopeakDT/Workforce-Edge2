"""
Main Application Entry Point
Workforce Management Backend

Supports Phase 0 → Phase 7 via feature flags.
Safe to run Phase 4 (Ingestion) today.
"""

# -------------------------------------------------
# Load environment variables FIRST
# -------------------------------------------------
from dotenv import load_dotenv
load_dotenv()

import os
import asyncio
from contextlib import asynccontextmanager
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

# -------------------------------------------------
# Feature flags (PHASE CONTROL)
# -------------------------------------------------
ENABLE_INGESTION = os.getenv("ENABLE_INGESTION", "true").lower() == "true"
ENABLE_ADMIN_API = os.getenv("ENABLE_ADMIN_API", "false").lower() == "true"
ENABLE_AGGREGATION = os.getenv("ENABLE_AGGREGATION", "false").lower() == "true"
ENABLE_ALERTS = os.getenv("ENABLE_ALERTS", "false").lower() == "true"

# -------------------------------------------------
# Conditional imports (IMPORTANT)
# -------------------------------------------------
if ENABLE_INGESTION:
    from api.event_ingest_api import router as event_router
    from api.heartbeat_ingest_api import router as heartbeat_router

if ENABLE_ADMIN_API:
    from api.admin_endpoints import router as admin_router

if ENABLE_AGGREGATION:
    from aggregation.missed_activity_cron import run_missed_activity_check
    from aggregation.device_health_monitor import run_device_health_monitor

# -------------------------------------------------
# Lifespan manager (background tasks)
# -------------------------------------------------
@asynccontextmanager
async def lifespan(app: FastAPI):
    tasks = []

    # Phase 5 – Aggregation
    if ENABLE_AGGREGATION:
        tasks.append(asyncio.create_task(run_missed_activity_check()))
        tasks.append(asyncio.create_task(run_device_health_monitor()))

    yield

    # Graceful shutdown
    for task in tasks:
        task.cancel()

# -------------------------------------------------
# FastAPI app
# -------------------------------------------------
app = FastAPI(
    title="Workforce Management System API",
    description="Multi-farm AI activity monitoring backend",
    version="1.0.0",
    lifespan=lifespan,
)

# -------------------------------------------------
# Middleware
# -------------------------------------------------
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # tighten later
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# -------------------------------------------------
# ROUTES (Phase-gated)
# -------------------------------------------------
API_PREFIX = "/api/v1"

if ENABLE_INGESTION:
    app.include_router(event_router, prefix=API_PREFIX)
    app.include_router(heartbeat_router, prefix=API_PREFIX)

if ENABLE_ADMIN_API:
    app.include_router(admin_router, prefix=API_PREFIX)

# -------------------------------------------------
# Infra endpoints
# -------------------------------------------------
@app.get("/")
def root():
    return {
        "service": "Workforce Management Backend",
        "ingestion": ENABLE_INGESTION,
        "admin_api": ENABLE_ADMIN_API,
        "aggregation": ENABLE_AGGREGATION,
        "alerts": ENABLE_ALERTS,
    }


@app.get("/health")
def health():
    return {"status": "healthy"}

# -------------------------------------------------
# Local dev entrypoint
# -------------------------------------------------
if __name__ == "__main__":
    import uvicorn
    uvicorn.run(
        "main:app",
        host="0.0.0.0",
        port=8000,
        reload=True,
    )
